#!/bin/sh -f

## Bijou script-ette to convert pstex files to eps.
## Maff Glover 13.08.2003
## SYNTAX: pstex2eps <filename>
## OUTPUT: pstex extension stripped and replaced with .eps

fname=$1

# Generate the latex file
cat <<EOF> pstex2eps.tex
\documentclass{article}
\usepackage{graphics}
\begin{document}
\thispagestyle{empty}
\begin{figure}
\centering
\input{$fname}
\end{figure}
\end{document} 
EOF

# Run latex
latex pstex2eps.tex >& /dev/null

# Generate EPS
seed=`echo $fname | awk -v FS=".pstex" '{print $1}'`
dvips -E pstex2eps.dvi -o $seed.eps >& /dev/null

############## Tidy up ##################

rm -f pstex2eps.tex
rm -f pstex2eps.dvi
rm -f pstex2eps.aux
rm -f pstex2eps.log

